"""The Chain runs self-critique based on the Constitutional AI method proposed by \
(Bai et al., 2022)."""
