How-To Guides
=============

Types
-----

The first set of examples all highlight different types of memory.


.. toctree::
   :maxdepth: 1
   :glob:

   ./types/*


Usage
-----

The examples here all highlight how to use memory in different ways.

.. toctree::
   :maxdepth: 1
   :glob:

   ./examples/*