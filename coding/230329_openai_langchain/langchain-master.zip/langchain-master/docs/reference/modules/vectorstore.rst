VectorStores
=============================

.. automodule:: langchain.vectorstores
   :members:
   :undoc-members: