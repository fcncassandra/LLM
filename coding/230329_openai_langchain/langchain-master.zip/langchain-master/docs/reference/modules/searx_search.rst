SearxNG Search
=============================

.. automodule:: langchain.utilities.searx_search
   :members:
   :undoc-members:
