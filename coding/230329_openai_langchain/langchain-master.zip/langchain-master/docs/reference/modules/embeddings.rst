Embeddings
===========================

.. automodule:: langchain.embeddings
   :members:
